use master
go
create database DTB_Project_Sem4
go
use DTB_Project_Sem4

/* bang user */
go

create table users
(
users_id int identity primary key ,
users_username varchar(20),
users_pass varchar(20),
users_rol nvarchar(20),
)
insert into users values('admin123','123456','admin')
insert into users values('intructor123','123456','intructor')
insert into users values('department123','123456','department')
go

/* bang chi tiet admin */
create table admin_detail
(
	users_id int foreign key(users_id) references users(users_id),
	admin_name nvarchar(200),
)
go
insert into admin_detail values(1,'im admin 01')
go
/* bang chi tiet intructor */
create table intructor_detail
(
	users_id  int foreign key(users_id) references users(users_id),
	intructor_name nvarchar(200),
	intructor_all_report int,
	intructor_all_lab int
)
go
insert into intructor_detail values(2,'Nguyen Van A','0','1')
go
select * from intructor_detail

/* bang chi tiet department */
create table department_detail
(
	users_id int foreign key(users_id) references users(users_id),
	department_name nvarchar(200),
	department_all_report int,
)
insert into department_detail values(3,'departmen man','0')

/* bang report */
create table report
(
report_id int identity primary key ,
users_id int foreign key(users_id) references users(users_id) ,
report_title nvarchar(100),
report_content nvarchar(1000),
report_timere datetime,
)
insert into report values(2,'may cheu bi hong','may chieu phong hoc khong hoat dong',22/06/2015)
select * from report

/* bang lab */
go
create table lab
(
lab_id int identity primary key ,
users_id int foreign key(users_id) references users(users_id),
lab_name nvarchar(20),
lab_quantity_student int,
lab_project nvarchar(200),
)

insert into lab values(2,'c1304g','30','project sem4')


